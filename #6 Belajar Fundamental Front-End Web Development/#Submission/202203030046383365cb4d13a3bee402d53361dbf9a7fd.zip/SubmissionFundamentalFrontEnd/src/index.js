import "regenerator-runtime";
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.min.js';
import "bootstrap-icons/font/bootstrap-icons.css";
import "./style/css/style.css";
import app from './style/js/app';

document.addEventListener("DOMContentLoaded", app);