class Restaurant {
  constructor(pictureId, name, description, city, rating) {
    this.pictureId = pictureId;
    this.name = name;
    this.description = description;
    this.city = city;
    this.rating = rating;
  }
}

export default Restaurant;
